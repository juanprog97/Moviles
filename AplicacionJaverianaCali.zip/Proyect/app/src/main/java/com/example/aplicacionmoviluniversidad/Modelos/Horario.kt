package com.example.aplicacionmoviluniversidad.Modelos

data class Horario (
    val salon: String?,
    val hora: String?,
    val dia: Int,
    val nombre: String?
)