package com.example.aplicacionmoviluniversidad.Modelos

data class DiaClase (
    val dia: Int?,
    val diaN: String?
)