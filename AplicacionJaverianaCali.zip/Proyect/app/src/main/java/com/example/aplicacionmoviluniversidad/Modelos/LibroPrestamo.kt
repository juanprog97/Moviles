package com.example.aplicacionmoviluniversidad.Modelos

data class LibroPrestamo (
    val codb: String?,
    val titu: String?,
    val stopo: String?,
    val fecp: String?,
    val fecd: String?,
    val mult: String?,
    val loca: String

)