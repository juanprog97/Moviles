package com.example.aplicacionmoviluniversidad.Modelos

data class UserModel (
    var nombre: String?,
    var user: String?,
    var password: String?,
    var apellido: String?,
    var email: String?,
    val periodo: String?,
    var emplid: String?,
    var nametoken: String?,
    var value: String?
)