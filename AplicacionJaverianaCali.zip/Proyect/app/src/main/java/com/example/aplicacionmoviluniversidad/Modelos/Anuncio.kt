package com.example.aplicacionmoviluniversidad.Modelos

data class Anuncio(
    val nid: String?,
    val Publicado: String?,
    val Path: String?,
    val title: String?,
    val type: String?,
    val body: String?,
    val field_image_box: String?
)
