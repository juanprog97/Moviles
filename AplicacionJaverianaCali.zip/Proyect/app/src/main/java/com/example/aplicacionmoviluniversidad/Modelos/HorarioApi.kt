package com.example.aplicacionmoviluniversidad.Modelos

data class HorarioApi (
    val feci : String?,
    val hora : String?,
    val saln : String?,
    val fecf: String?,
    val doc: String?,
    val dia: Int

)

