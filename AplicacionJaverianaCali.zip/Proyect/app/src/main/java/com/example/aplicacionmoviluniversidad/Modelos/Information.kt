package com.example.aplicacionmoviluniversidad.Modelos

data class Information (
    val lastPage: Int,
    val rows: List<Anuncio>
)
