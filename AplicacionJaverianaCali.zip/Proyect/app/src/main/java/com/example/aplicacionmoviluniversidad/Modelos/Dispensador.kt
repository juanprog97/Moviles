package com.example.aplicacionmoviluniversidad.Modelos

data class Dispensador(
    val nombreLugar: String?,
    val numDisponible: Int?
)
