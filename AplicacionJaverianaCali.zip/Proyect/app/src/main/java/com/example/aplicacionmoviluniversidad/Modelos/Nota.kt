package com.example.aplicacionmoviluniversidad.Modelos

data class  Nota(
    val nombre: String?,
    val nota: Double?,
    val porcentaje: Int?

)